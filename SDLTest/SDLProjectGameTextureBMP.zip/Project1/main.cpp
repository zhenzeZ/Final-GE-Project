#include <SDL.h>
#include <SDL_image.h>
#include <iostream>
#include "Game.h"

using namespace std;

int main(int argc, char** argv){

	DEBUG_MSG("Game Object Created");

	Game* game = new Game();

	//Adjust screen positions as needed
	game->Initialize("DGPP Skelatol",300,100,800,600, SDL_WINDOW_INPUT_FOCUS);
	DEBUG_MSG("Game Initialised");

	game->LoadContent();

	DEBUG_MSG("Game Loop Starting......");
	while(game->IsRunning())
	{
		game->HandleEvents();
		game->Update();
		game->Render();
	}

	game->UnloadContent();
	DEBUG_MSG("Calling Cleanup");
	game->CleanUp();
	
	return 0;
}
